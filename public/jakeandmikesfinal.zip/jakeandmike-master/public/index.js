var config = {
    apiKey: "AIzaSyD6HH1rpcgkroqxn79qnIwT3CGg3W2RnLU",
    authDomain: "jakeandmikesfinal.firebaseapp.com",
    databaseURL: "https://jakeandmikesfinal.firebaseio.com",
    projectId: "jakeandmikesfinal",
    storageBucket: "jakeandmikesfinal.appspot.com",
    messagingSenderId: "255222212593"
};

firebase.initializeApp(config);
